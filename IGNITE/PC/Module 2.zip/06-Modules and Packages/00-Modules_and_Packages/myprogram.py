from MyMainPackage.some_main_script import report_main
from MyMainPackage.SubPackage import mysubscript

report_main()

mysubscript.sub_report()
